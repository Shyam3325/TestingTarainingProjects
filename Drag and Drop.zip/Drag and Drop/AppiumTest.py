from appium import webdriver
from appium.options.android import UiAutomator2Options
import time

desired_caps={
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "vivo 1819",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": "8000",
    "appium:connectHardwareKeyboard": True,
    "appium:appPackage": "com.advitasoftware.constitution_of_india",
    "appium:appActivity": "host.exp.exponent.MainActivity"
}
options = UiAutomator2Options().load_capabilities(desired_caps)
driver = webdriver.Remote("http://localhost:4723",options=options)
time.sleep(10)

driver.quit()



