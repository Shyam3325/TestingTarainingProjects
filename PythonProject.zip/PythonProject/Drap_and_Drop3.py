from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
import time


baseUrl="https://testautomationpractice.blogspot.com/"
driver = webdriver.Chrome()
driver.maximize_window()
driver.get(baseUrl)
time.sleep(5)


driver.execute_script("window.scrollBy(0,1500);")
time.sleep(2)

fromElement =driver.find_element(By.ID,"draggable")
toElement =driver.find_element(By.ID,"droppable")

try:
    actions = ActionChains(driver)
    actions.drag_and_drop(fromElement,toElement).perform()
    time.sleep(3)

    print("Drag and Drop elements successful")
except:
    print("Drag and Drop failed on element")