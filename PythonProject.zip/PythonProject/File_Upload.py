from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
import time


baseUrl="https://demo.automationtesting.in/FileDownload.html/"
driver = webdriver.Chrome()
driver.maximize_window()
driver.get(baseUrl)
time.sleep(5)

driver.execute_script("window.scrollBy(0,1300)")
time.sleep(5)

driver.find_element(By.ID,)