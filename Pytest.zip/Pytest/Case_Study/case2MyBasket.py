import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import re

#step:5
#Verify all the products are added to the basket
class My_Basket_and_SubTotal():

    def __init__(self,driver):
        self.driver = driver

    def ClickMyB(self):
        self.driver.find_element(By.CSS_SELECTOR, ".HeaderLinkIcon-module_button__C7r3R svg").click()


#Step:6
#Verify the subtotal of the products (quantity * price) and total of the basket


    def SubTotal(self):

        products = self.driver.find_elements(By.CSS_SELECTOR, ".basket-item")

        subtotal_calculated = 0

        for product in products:
            quantity = int(product.find_element(By.CSS_SELECTOR, ".quantity").text)

            price_text = product.find_element(By.CSS_SELECTOR, ".product-price").text
            price = float(price_text.replace("£", "").strip())

            product_subtotal = quantity * price
            subtotal_calculated += product_subtotal

            print(f"Product: {product}, Quantity: {quantity}, Price: {price}, Subtotal: {product_subtotal}")




        displayed_Total_Items =self.driver.find_element(By.XPATH,"//span[@class='jsx-1755698353 price-label__quantifier']").text

        displayed_subtotal_text = self.driver.find_element(By.XPATH,
                                                           "//div[contains(text(),'Total')]//following-sibling::div").text

        price_match = re.search(r'£(\d+\.\d+)', displayed_subtotal_text)
        if price_match:
            displayed_subtotal = float(price_match.group(1))
        else:
            raise ValueError(f"Unable to extract price from text: {displayed_subtotal_text}")

        print(f"Displayed Subtotal: £{displayed_subtotal}")
        print(f"Displayed Total Items: {displayed_Total_Items}")


        self.driver.find_element(By.XPATH, "//button[normalize-space()='Checkout']").click()
        time.sleep(3)

    def login(self):
        self.ClickMyB()
        self.driver.save_screenshot(".//ClickMyB.png")
        self.SubTotal()
        self.driver.save_screenshot(".//Subtotal.png")