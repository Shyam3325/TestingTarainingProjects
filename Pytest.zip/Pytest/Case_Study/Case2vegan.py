import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Step:4
# Add any 3 Vegan Chocolate products from 'Vegan' to the basket

class Add_vegan_items():

    def __init__(self, driver):
        self.driver = driver


    _Home_btn = "//a[normalize-space()='Home']"
    _veganChocolate_btn = "//button[normalize-space()='Vegan Chocolate']"
    _partial_link = "Vegan"
    def ClickHome(self):
        return self.driver.find_element(By.XPATH,self._Home_btn)


    def getVegan(self):
        return self.driver.find_element(By.PARTIAL_LINK_TEXT, self._partial_link)

    def getVeganChocolate(self):
        return self.driver.find_element(By.XPATH,self._veganChocolate_btn)


    def ClickHm(self):
        self.ClickHome().click()

    def ClickVegan(self):
        self.getVegan().click()

    def clickvgchoc(self):
        self.getVeganChocolate().click()
        time.sleep(3)



    def AddVeganItems(self):
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
        time.sleep(3)
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
        time.sleep(3)
        self.driver.find_element(By.CSS_SELECTOR,"*[data-test=\"button-ProductCard\"]").click()
        time.sleep(3)


    def login(self):
        self.ClickHm()
        self.getVegan()
        self.clickvgchoc()
        self.AddVeganItems()
        self.driver.save_screenshot(".//AddVeganItems.png")