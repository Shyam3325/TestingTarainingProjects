import pytest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import re


#Step:1
#Open the website
class TestHBTestAdd():
  def setup_method(self, method):
    self.driver = webdriver.Chrome()
    self.vars = {}
  
  def teardown_method(self, method):
    self.driver.quit()
  
  def test_hBTestAdd(self):
    self.driver.get("https://www.hollandandbarrett.com/")
    time.sleep(5)
    self.driver.set_window_size(1616, 876)
    element = self.driver.find_element(By.CSS_SELECTOR, ".SearchBar-module_searchIconWrapper__BuFsk")
    actions = ActionChains(self.driver)
    actions.move_to_element(element).perform()
    self.driver.save_screenshot(".//actions .png")

    #Step:2
    #Login with the registered user
    self.driver.find_element(By.CSS_SELECTOR, ".MyHB-module_title__2fm-3").click()
    element = self.driver.find_element(By.CSS_SELECTOR, "body")
    actions = ActionChains(self.driver)
    actions.move_to_element(element).perform()

    self.driver.find_element(By.ID, "username").send_keys("shyam143pr@gmail.com")
    self.driver.find_element(By.ID, "password").send_keys("Sam@pr9493!")
    self.driver.find_element(By.NAME, "action").click()
    self.driver.save_screenshot(".//action screenshot.png")

    #Step:3
    #Add any 2 vitamin C products from 'Vitamins & Supplements' to the basket
    self.driver.get("https://www.hollandandbarrett.com/")
    self.driver.execute_script("window.scrollTo(0,31)")
    self.driver.execute_script("window.scrollTo(0,252)")
    self.driver.find_element(By.CSS_SELECTOR, "div:nth-child(4) > .CategoryButtonsHP-module_carouselItem__FyNEN").click()
    self.driver.find_element(By.CSS_SELECTOR, "div:nth-child(3) .CategoryButtonsHP-module_carouselItem__p8SXL").click()
    element = self.driver.find_element(By.CSS_SELECTOR, ".NavCategoryItem-module_categoryItemWrapper__cTqDy:nth-child(4) .NavCategoryItem-module_categoryImage__Ho9KS")
    actions = ActionChains(self.driver)
    actions.move_to_element(element).perform()
    self.driver.find_element(By.CSS_SELECTOR, ".NavCategoryItem-module_categoryItemWrapper__cTqDy:nth-child(4) .NavCategoryItem-module_categoryImage__Ho9KS").click()
    self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
    time.sleep(3)
    self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
    self.driver.save_screenshot(".//*[data-test=\"button-ProductCard\"].png")
    time.sleep(3)

    #Step:4
    #Add any 3 Vegan Chocolate products from 'Vegan' to the basket

    self.driver.find_element(By.LINK_TEXT, "Home").click()
    self.driver.find_element(By.CSS_SELECTOR, ".CategoryButtonsHP-module_lastItem__UwN1J").click()
    self.driver.find_element(By.CSS_SELECTOR, "div:nth-child(7) .CategoryButtonsHP-module_carouselItem__p8SXL").click()
    self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
    time.sleep(3)
    self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
    time.sleep(3)
    self.driver.find_element(By.CSS_SELECTOR,"a:nth-child(3) div:nth-child(1) div:nth-child(3) div:nth-child(2) button:nth-child(1)").click()
    self.driver.save_screenshot(".//CSS_SELECTOR.png")
    time.sleep(3)

    #Step:5
    #Verify all the products are added to the basket
    self.driver.find_element(By.CSS_SELECTOR, ".HeaderLinkIcon-module_button__C7r3R svg").click()
    self.driver.save_screenshot(".//click.png")
    time.sleep(3)

    #Step:6
    #Verify the subtotal of the products (quantity * price) and total of the basket

    products = self.driver.find_elements(By.CSS_SELECTOR, ".basket-item")

    subtotal_calculated = 0

    for product in products:
      quantity = int(product.find_element(By.CSS_SELECTOR, ".quantity").text)

      price_text = product.find_element(By.CSS_SELECTOR, ".product-price").text
      price = float(price_text.replace("£", "").strip())

      product_subtotal = quantity * price
      subtotal_calculated += product_subtotal

      print(f"Product: {product}, Quantity: {quantity}, Price: {price}, Subtotal: {product_subtotal}")

    displayed_subtotal_text = self.driver.find_element(By.XPATH, "//div[contains(text(),'Total')]//following-sibling::div").text
    price_match = re.search(r'£(\d+\.\d+)', displayed_subtotal_text)
    if price_match:
      displayed_subtotal = float(price_match.group(1))
    else:
      raise ValueError(f"Unable to extract price from text: {displayed_subtotal_text}")


    print(f"Displayed Subtotal: £{displayed_subtotal}")

    self.driver.save_screenshot(".//By.XPATH.png")

    self.driver.find_element(By.XPATH,"//button[normalize-space()='Checkout']").click()
    time.sleep(3)

    self.driver.quit()






  
