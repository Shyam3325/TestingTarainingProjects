import time
from selenium import webdriver
import unittest
from CaseStudy1 import LoginPage
from Case1Vitamins import Add_Vtamin_C_Items
from Case1Vegan import Add_vegan_items




class LoginTests(unittest.TestCase):

    def test_validLogin(self):
        baseUrl = "https://auth.hollandandbarrett.com/u/login"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        time.sleep(5)

        lp = LoginPage(driver)
        lp.login("shyam143pr@gmail.com","Sam@pr9493!")
        vitamin =Add_Vtamin_C_Items(driver)
        vitamin.get()
        vitamin.ClickVitaminsandSupplements()
        vitamin.Clickvitamins()
        vitamin.clickvitaminC()
        vitamin.AddItemsVitaminC()
        vegan =Add_vegan_items(driver)
        vegan.ClickHm()
        vegan.ClickVegan()
        vegan.clickvgchoc()
        vegan.AddVeganItems()
        vegan.ClickMyB()
        vegan.ClickCheckout()


















