import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
import time


class Add_Vtamin_C_Items():


    def __init__(self, driver):
        self.driver = driver
# Step:3
# Add any 2 Vitamin C products from 'Vitamins & Supplements' to the basket


    _vitamin_btn = "//button[normalize-space()='Vitamins']"
    _vitaminC_btn = "//div[normalize-space()='Vitamin C']"
    _partial_link = "Vitamins"

    def get(self):
        self.driver.get("https://auth.hollandandbarrett.com/")
        time.sleep(4)



    def getVitaminandSupplements(self):
        return self.driver.find_element(By.PARTIAL_LINK_TEXT, self._partial_link)

    def getVitamins(self):
        return self.driver.find_element(By.XPATH, self._vitamin_btn)

    def getVitaminC(self):
        return self.driver.find_element(By.XPATH, self._vitaminC_btn)

    def ClickVitaminsandSupplements(self):
        self.getVitaminandSupplements().click()

    def Clickvitamins(self):
        self.getVitamins().click()

    def clickvitaminC(self):
        self.getVitaminC().click()


    def AddItemsVitaminC(self):
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
        time.sleep(3)
        self.driver.find_element(By.CSS_SELECTOR, "*[data-test=\"button-ProductCard\"]").click()
        time.sleep(3)

    def login(self):
     self.get()
     self.getVitaminandSupplements()
     self.Clickvitamins()
     self.clickvitaminC()
     self.AddItemsVitaminC()
     time.sleep(2)
     self.driver.save_screenshot(".//AddItemsVitaminC.png")