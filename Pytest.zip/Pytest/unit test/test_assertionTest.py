import unittest#File name must test_or ends with _test
from selenium import webdriver

class Test(unittest.TestCase):
    def testName(self):
        driver = webdriver.Chrome()
        driver.get("https://www.google.co.in/")
        TitleOfBrowser = driver.title
        self.assertTrue(TitleOfBrowser == "Google")

if __name__ == "__main__":
    unittest.main()


