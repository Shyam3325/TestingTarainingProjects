import time
from selenium import webdriver
import unittest
from Login_Page import LoginPage



class LoginTests(unittest.TestCase):

    def test_validLogin(self):
        baseUrl = "https://auth.hollandandbarrett.com/u/login"
        driver = webdriver.Chrome()
        driver.maximize_window()
        driver.get(baseUrl)
        time.sleep(5)

        lp = LoginPage(driver)
        lp.login("shyam143pr@gmail.com","Sam@pr9493!")

        actual_title =driver.title
        expected_title ="Sign in - to your account, for the best experience"

        if actual_title == expected_title:
            print("Login is Successful .....well done python")
        else:
            print("Login Unsuccessful ..... Very good my boy!")


