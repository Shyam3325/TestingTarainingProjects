import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By


class LoginPage():


    def __init__(self,driver):
        self.driver=driver


    #locators
    _email_field ="email"
    _password_field ="password"
    _Login_Button="//button[@id='login']"


    def getEmailFeild(self):
        return self.driver.find_element(By.ID,self._email_field)


    def getPasswordFeild(self):
        return self.driver.find_element(By.NAME,self._password_field)


    def getLoginButton(self):
        return self.driver.find_element(By.XPATH,self._Login_Button)


    def enterEmail(self,email):
        self.getEmailFeild().send_keys(email)


    def enterPassword(self,password):
        self.getPasswordFeild().send_keys(password)


    def clickLoginButton(self):
        self.getLoginButton().clcik()


    def login(self,email,password):
        self.enterEmail(email)
        self.enterPassword(password)
        self.clickLoginButton()