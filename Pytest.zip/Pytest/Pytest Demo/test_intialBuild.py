def test_smokeTesting():
    print("This is SmokeTesting")

def test_SanityTesting():
    print("This is SanityTesting")


def test_EndtoEndTesting():
    print("This is EndtoEndTesting")
    assert False

def test_RegresionTesting():
    print("This is RegressionTesting")