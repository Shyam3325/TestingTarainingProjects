import pytest
from openpyxl.xml.constants import XPROPS_NS
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

class LoginPage():

    def __init__(self,driver):
        self.driver=driver
    #locators
    _mobilenumber_field = "ap_email"
    _password_field = "ap_password"
    _continue_button = "//input[@id='continue']"
    _sign_in_button = "//input[@id='signInSubmit']"

    def getMobileNumberField(self):
        return self.driver.find_element(By.ID, self._mobilenumber_field)

    def getclickContinueButton(self):
        return self.driver.find_element(By.XPATH, self._continue_button)


    def getPasswordField(self):
        return self.driver.find_element(By.ID, self._password_field)

    def getSignInButton(self):
        return self.driver.find_element(By.XPATH, self._sign_in_button)

    def enterMobileNumber(self, mobilenumber):
        self.getMobileNumberField().send_keys(mobilenumber)
        time.sleep(3)

    def clickContinueButton(self):
        self.getclickContinueButton().click()

    def enterPassword(self, password):
        self.getPasswordField().send_keys(password)

    def clickSignInButton(self):
        self.getSignInButton().click()

    def login(self, mobilenumber, password):
        self.enterMobileNumber(mobilenumber)
        self.clickContinueButton()
        self.enterPassword(password)
        self.clickSignInButton()
        self.driver.close()
        time.sleep(5)





