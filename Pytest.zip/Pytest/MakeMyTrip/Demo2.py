import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

class Add_to_Cart():

    def __init__(self,driver):
        self.driver=driver


    # locators
    _nav_field = "//span[@class='nav-cart-icon nav-sprite']"
    _add_to_cart_field = "//input[@id='add-to-cart-button']"

    def get(self):
        self.driver.get("https://www.amazon.in/")
        time.sleep(4)

    def getclickNavField(self):
        return self.driver.find_element(By.XPATH, self._nav_field)

    def getclickAddtoCartField(self):
        return self.driver.find_element(By.XPATH, self._add_to_cart_field)

    def clickNavField(self):
        self.getNavField().click()

    def clickAddtoCartField(self):
        self.getAddtoCartField().click()

    def addtocart(self):
        self.get()
        self.clickNavField()
        self.clickAddtoCartField()