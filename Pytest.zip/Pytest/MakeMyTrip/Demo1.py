import time
import unittest

from selenium import webdriver

from Demo import LoginPage
from Demo2 import Add_to_Cart


class LoginTests(unittest.TestCase):

    def test_validateLogin(self):
        baseUrl = "https://www.amazon.in/"
        driver = webdriver.Chrome()
        driver.get(baseUrl)

        driver.maximize_window()
        time.sleep(5)


        lp = LoginPage(driver)
        lp.login("9177583383","Divya@2001")

        lp1 = Add_to_Cart(driver)
        lp1.get()
        lp1.getclickNavField()
        lp1.clickAddtoCartField()




