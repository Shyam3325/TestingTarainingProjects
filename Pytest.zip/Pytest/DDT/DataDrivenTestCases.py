import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import XLUtilities

driver = webdriver.Chrome()
driver.get("https://www.letskodeit.com/login")
driver.maximize_window()

path = "C://Shyam_selenium_prac/ShyamTbl.xlsx"

rows = XLUtilities.getRowCount(path, "Sheet1")

for r in range(2, rows + 1):
    username = XLUtilities.readData(path, "Sheet1", r, 1)
    password = XLUtilities.readData(path, "Sheet1", r, 2)

    email_field = driver.find_element(By.ID, "email")
    password_field = driver.find_element(By.NAME, "password")


    email_field.clear()
    password_field.clear()


    email_field.send_keys(username)
    password_field.send_keys(password)


    driver.find_element(By.XPATH, "//button[@id='login']").click()
    time.sleep(3)


    driver.find_element(By.XPATH, "//img[@class='zl-navbar-rhs-img ']").click()
    driver.find_element(By.XPATH, "//a[normalize-space()='Logout']").click()
    time.sleep(3)




    if driver.title == "Home Page":
        print("Test is Passed")
        XLUtilities.writeData(path, "Sheet1", r, 3, "passed")
    else:
        print("Test is Failed")
        XLUtilities.writeData(path, "Sheet1", r, 3, "Failed")

    driver.find_element(By.XPATH, "//a[normalize-space()='Sign In']").click()
    time.sleep(3)




