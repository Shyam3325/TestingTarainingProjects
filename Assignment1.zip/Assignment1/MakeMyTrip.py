from selenium import webdriver
from selenium.webdriver.common.by import By
import time

baseURL = "https://www.makemytrip.com/"
driver = webdriver.Chrome()
driver.maximize_window()
driver.get(baseURL)

