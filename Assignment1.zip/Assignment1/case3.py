from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import time

driver = webdriver.Chrome()

driver.get('https://www.hollandandbarrett.com/en-au/')


driver.maximize_window()

username = driver.find_element(By.ID, 'username')
password = driver.find_element(By.ID, 'password')

username.send_keys('shyam143pr@gmail.com')
password.send_keys('Sam@pr9493!')


login_button = driver.find_element(By.XPATH, "/html/body/main/section/div/div/div/form/div[2]/button")
login_button.click()

# Wait for login to complete
time.sleep(3)


vitamin_section = driver.find_element(By.XPATH, "//a[contains(text(),'Vitamins & Supplements')]")
vitamin_section.click()


time.sleep(2)

vitamin_c_product1 = driver.find_element(By.XPATH, "//a[contains(@href,'vitamin-c')]")
vitamin_c_product1.click()
time.sleep(1)
add_to_basket1 = driver.find_element(By.XPATH, "//button[@aria-label='Add to Basket']")
add_to_basket1.click()
time.sleep(2)

# Go back to the category
driver.back()
time.sleep(2)

# Select the second Vitamin C product
vitamin_c_product2 = driver.find_element(By.XPATH, "//a[contains(@href,'vitamin-c')]")
vitamin_c_product2.click()
time.sleep(1)
add_to_basket2 = driver.find_element(By.XPATH, "//button[@aria-label='Add to Basket']")
add_to_basket2.click()
time.sleep(2)

# 4. Add 3 Vegan Chocolate products from 'Vegan' to the basket
# Navigate to Vegan section
vegan_section = driver.find_element(By.XPATH, "//a[contains(text(),'Vegan')]")
vegan_section.click()

# Wait for the page to load
time.sleep(2)

# Select the first 3 Vegan Chocolate products
vegan_chocolate_product1 = driver.find_element(By.XPATH, "//a[contains(@href,'vegan-chocolate')]")
vegan_chocolate_product1.click()
time.sleep(1)
add_to_basket1_vegan = driver.find_element(By.XPATH, "//button[@aria-label='Add to Basket']")
add_to_basket1_vegan.click()
time.sleep(2)

# Go back to the category
driver.back()
time.sleep(2)

# Select the second Vegan Chocolate product
vegan_chocolate_product2 = driver.find_element(By.XPATH, "//a[contains(@href,'vegan-chocolate')]")
vegan_chocolate_product2.click()
time.sleep(1)
add_to_basket2_vegan = driver.find_element(By.XPATH, "//button[@aria-label='Add to Basket']")
add_to_basket2_vegan.click()
time.sleep(2)

# Go back to the category
driver.back()
time.sleep(2)

# Select the third Vegan Chocolate product
vegan_chocolate_product3 = driver.find_element(By.XPATH, "//a[contains(@href,'vegan-chocolate')]")
vegan_chocolate_product3.click()
time.sleep(1)
add_to_basket3_vegan = driver.find_element(By.XPATH, "//button[@aria-label='Add to Basket']")
add_to_basket3_vegan.click()
time.sleep(2)

# 5. Verify all the products are added to the basket
# Navigate to the Basket
basket_icon = driver.find_element(By.XPATH, "//a[@href='/en-au/basket']")
basket_icon.click()

# Wait for the basket page to load
time.sleep(2)

# Get the list of items in the basket
items_in_basket = driver.find_elements(By.XPATH, "//div[@class='product-name']")
assert len(items_in_basket) == 5, f"Expected 5 products, found {len(items_in_basket)} products."

# 6. Verify subtotal of the products and total of the basket
subtotal = driver.find_element(By.XPATH, "//div[contains(text(),'Subtotal')]//following-sibling::div")
total = driver.find_element(By.XPATH, "//div[contains(text(),'Total')]//following-sibling::div")

print("Subtotal:", subtotal.text)
print("Total:", total.text)

# 7. Print the Page Title
print("Page Title:", driver.title)

# 8. Get page source and page source length
page_source = driver.page_source
print("Page Source Length:", len(page_source))

# 9. Close the Browser
driver.quit()
