import time
from selenium import webdriver
from selenium.webdriver.common.by import By
#Part:-1
#Launch the URL on Firefox
driver=webdriver.Firefox()
driver.get("https://demo.opencart.com.gr/")
driver.maximize_window()
time.sleep(5)

#Verify Title of the Page
actual_title = driver.title
expect_title = "Your Store"

if actual_title == expect_title:
    print("Title Verified")
else:
    print("Title Not Verified")

#Click on "My Account" dropdown
My_Account = driver.find_element(By.XPATH,"//span[@class='caret']")
My_Account.click()
time.sleep(3)

#Slect "Register" option
Register = driver.find_element(By.XPATH,"//a[normalize-space()='Register']")
Register.click()
time.sleep(2)

#Verify the text present on the web page as "Register Account"
actual_title = driver.title
expect_title = "Register Account"

if actual_title == expect_title:
    print("Webpage Title Verified")
else:
    print("Webpage Title Not Verified")

#Click on 'Continue' button on the bottom of the page
driver.find_element(By.XPATH, "//input[@value='Continue']").click()
time.sleep(5)

#Part:-2
#Enter data in 'First Name' textbox
FirstName=driver.find_element(By.NAME,'firstname').send_keys("Shyam")
FirstName.clear()






