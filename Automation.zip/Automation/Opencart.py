import pytest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.common.keys import Keys


#Step:1(Login with credentials created in Lab1)
class TestOpencart():
    def setup_method(self, method):
        self.driver = webdriver.Chrome()
        self.vars = {}

    def teardown_method(self, method):
        self.driver.quit()

    def test_opencart(self):
        self.driver.get("https://demo.opencart.com.gr/")
        self.driver.maximize_window()
        time.sleep(5)
        self.driver.find_element(By.CSS_SELECTOR, ".dropdown .hidden-xs").click()
        time.sleep(3)
        self.driver.find_element(By.LINK_TEXT, "Login").click()
        time.sleep(3)
        self.driver.find_element(By.ID, "input-email").send_keys("shyam143pr@gmail.com")
        self.driver.find_element(By.NAME, "password").send_keys("Sam@pr9493!")
        self.driver.find_element(By.XPATH, "//input[@value='Login']").click()
        time.sleep(2)

#Step:2(Go to components tab and click)
        self.driver.find_element(By.XPATH,"//a[normalize-space()='Components']").click()
        time.sleep(3)
#Step:3(Select 'Monitors')
        self.driver.find_element(By.XPATH, "//a[normalize-space()='Monitors (2)']").click()
        time.sleep(3)

#Step:4(Select 25 From Show Drop down)
        self.driver.find_element(By.ID, "input-limit").click()
        time.sleep(3)
        self.driver.find_element(By.XPATH, "//option[@value='https://demo.opencart.com.gr/index.php?route=product/category&path=25_28&limit=25']").click()
        time.sleep(3)

#Step:5(Click on "Add to cart" for the first item
        self.driver.find_element(By.XPATH,"//div[@id='content']//div[1]//div[1]//div[2]//div[2]//button[1]//span[1]").click()
        time.sleep(3)
#Step:6(Click on "specification" tab)
        self.driver.find_element(By.LINK_TEXT, "Specification").click()
        time.sleep(3)

#Step:7(Verify details present on the page)

#Step:8(Click on "Add to wishlist button")
        self.driver.find_element(By.XPATH,"//div[@id='product-product']//div[@class='btn-group']//button[1]").click()
        time.sleep(5)
#Step:9(verify message "Success: you have added Apple Cinema 30" to your wish list)
        self.driver.find_element(By.CSS_SELECTOR, ".alert-success")
        success_message = self.driver.find_element(By.CSS_SELECTOR, ".alert-success").text
        assert "Success: You have added Apple Cinema 30" in success_message, "Item was not added to wishlist."
#Step:10(Enter mobile in search Text box)
        self.driver.find_element(By.NAME,"search").send_keys("Mobile")
        time.sleep(3)

#Step:11(Click on 'search' button)
        self.driver.find_element(By.XPATH,"//button[@class='btn btn-default btn-lg']").click()
        time.sleep(3)
#Step:12(Click on 'Search in product' checkbox
        checkbox=self.driver.find_element(By.XPATH,"//input[@id='description']")
        checkbox.click()
        time.sleep(2)
        self.driver.find_element(By.XPATH,"//input[@id='button-search']").click()
        time.sleep(5)
#Step:13(Click on link 'HTC TOUCH Hd' for the mobile 'HTC TOUCH HD'
        self.driver.find_element(By.XPATH,"//a[normalize-space()='HTC Touch HD']").click()
        time.sleep(5)
#Clear '1' from quantity and enter '3'
        qty_field =self.driver.find_element(By.ID,"input-quantity")
        qty_field.clear()
        qty_field.send_keys("3")
        time.sleep(2)
#Click on "Add to cart" Button
        self.driver.find_element(By.XPATH,"//button[@id='button-cart']").click()
        time.sleep(2)

# Optionally, verify that the item is added to the cart
        cart_count = self.driver.find_element(By.XPATH, "//span[@id='cart-total']").text
        assert "3 item(s)" in cart_count, "Item count in cart is incorrect."

#Click on 'View cart' button adjacent to search button
        self.driver.find_element(By.XPATH,"(//i[@class='fa fa-shopping-cart'])[2]").click()
        time.sleep(3)
        self.driver.find_element(By.XPATH,"//strong[normalize-space()='View Cart']").click()
        time.sleep(3)

#Verify mobile name added to the cart
        ProductName=self.driver.find_element(By.TAG_NAME,"a").text
        print(ProductName)
        time.sleep(3)


#Click on checkout Button
        self.driver.find_element(By.XPATH, "//button[@class='btn btn-danger']").click()
        time.sleep(3)
        self.driver.find_element(By.XPATH,"//a[@class='btn btn-primary']").click()

#Click on "MyAccount" Drop down
        self.driver.find_element(By.XPATH, "//span[@class='caret']").click()
        time.sleep(2)


#Click on "Log out" from dropdown
        self.driver.find_element(By.XPATH, "//a[normalize-space()='Logout']").click()
        time.sleep(3)

#Verify "Logout Account" heading
        actual_title = self.driver.title
        expect_title = "Account Logout"

        if actual_title == expect_title:
                print("Title Verified")
        else:
                print("Title Not Verified")

#Click on continue
        self.driver.find_element(By.XPATH,"//a[normalize-space()='Continue']").click()
        time.sleep(2)

        self.driver.quit()

























