
from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions
#Open Chrome and get URL:
driver = webdriver.Chrome()
baseURL="https://www.makemytrip.com/"
driver.maximize_window()
driver.get(baseURL)
time.sleep(5)
driver.find_element(By.XPATH,"//span[@class='commonModal__close']").click()

Select_From=driver.find_element(By.XPATH,"//div[@class='flt_fsw_inputBox searchCity inactiveWidget ']/label")
Select_From.click()
time.sleep(3)
search_input=driver.find_element(By.XPATH,"//div[@class='autoSuggestPlugin hsw_autocomplePopup']/div/input")
search_input.send_keys("Bengaluru")


wait = WebDriverWait(driver, 10)
dynamic_list = wait.until(expected_conditions.presence_of_all_elements_located((By.CSS_SELECTOR, "p.font14.appendBottom5.blackText")))

# Iterate through the list and select the desired city
desired_city = "Bengaluru, India"  # Change this to the city you want to select
for element in dynamic_list:
    if element.text.strip() == desired_city:
        print(element.is_displayed())
        element.click()
        time.sleep(3)
        break
else:
    print(f"City '{desired_city}' not found in the list.")

Search_To =driver.find_element(By.XPATH,"//div[contains(@class,'flt_fsw_inputBox searchToCity inactiveWidget')]/label")
Search_To.click()
time.sleep(3)
search_input=driver.find_element(By.XPATH,"//div[@class='autoSuggestPlugin hsw_autocomplePopup makeFlex column spaceBetween']/div/input")
search_input.send_keys("Hyderabad")


wait = WebDriverWait(driver, 10)
dynamic_list = wait.until(expected_conditions.presence_of_all_elements_located((By.CSS_SELECTOR, "p.font14.blackText.appendBottom5")))

# Iterate through the list and select the desired city
desired_city = "Hyderabad, India"  # Change this to the city you want to select
for element in dynamic_list:
    if element.text.strip() == desired_city:
        element.click()
        time.sleep(3)
        break
else:
    print(f"City '{desired_city}' not found in the list.")

driver.find_element(By.XPATH,"//div[@aria-label='Sat Dec 21 2024']").click()
time.sleep(3)
traveller = driver.find_element(By.XPATH,"//span[@class='lbl_input appendBottom5']")
traveller.click()

time.sleep(3)
driver.find_element(By.XPATH,"/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[2]/div[1]/ul[1]/li[2]").click()
time.sleep(3)
driver.find_element(By.XPATH,"//button[normalize-space()='APPLY']").click()
time.sleep(3)
driver.find_element(By.XPATH,"//a[normalize-space()='Search']").click()
time.sleep(3)




















