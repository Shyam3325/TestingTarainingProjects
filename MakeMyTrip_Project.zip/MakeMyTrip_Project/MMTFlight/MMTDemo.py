import pytest
import time
import json
import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


class TestMMT1(unittest.TestCase):
    def setup_method(self, method):
        self.driver = webdriver.Chrome()
        self.vars = {}

    def teardown_method(self, method):
        self.driver.quit()

    def test_mMT1(self):
        self.driver.get("https://www.makemytrip.com/")
        self.driver.set_window_size(1616, 876)
        time.sleep(5)
        element = self.driver.find_element(By.CSS_SELECTOR, ".font16:nth-child(1) > span")
        actions = ActionChains(self.driver)
        actions.move_to_element(element).perform()
        self.driver.find_element(By.XPATH, "//img[@alt='signInByMailButton']").click()
        self.driver.find_element(By.XPATH, "//input[@placeholder='Enter Email Address']").send_keys(
            "shyam143pr@gmail.com")
        time.sleep(3)
        self.driver.find_element(By.CSS_SELECTOR, ".font16:nth-child(1) > span").click()
        self.driver.find_element(By.ID, "password").click()
        self.driver.find_element(By.ID, "password").send_keys("Sam@pr9493!")
        self.driver.find_element(By.CSS_SELECTOR, ".font16:nth-child(1) > span").click()
        self.driver.find_element(By.CSS_SELECTOR, ".searchCity").click()
        self.driver.find_element(By.CSS_SELECTOR, ".react-autosuggest__input").send_keys("Ban")
        self.driver.find_element(By.CSS_SELECTOR,
                                 "#react-autowhatever-1-section-0-item-0 .searchedResult > .makeFlex").click()
        self.driver.find_element(By.CSS_SELECTOR, ".searchToCity").click()
        self.driver.find_element(By.CSS_SELECTOR, ".react-autosuggest__input").send_keys("Hy")
        self.driver.find_element(By.CSS_SELECTOR,
                                 "#react-autowhatever-1-section-0-item-0 .searchedResult > .makeFlex").click()
        self.driver.find_element(By.CSS_SELECTOR,
                                 ".DayPicker-Month:nth-child(1) .DayPicker-Week:nth-child(3) > .DayPicker-Day:nth-child(1) p:nth-child(1)").click()
        self.driver.find_element(By.CSS_SELECTOR, ".DayPicker-Day--start p:nth-child(1)").click()
        self.driver.find_element(By.CSS_SELECTOR, "label:nth-child(2) > .lbl_input").click()
        self.driver.find_element(By.CSS_SELECTOR,
                                 ".DayPicker-Month:nth-child(1) .DayPicker-Week:nth-child(3) > .DayPicker-Day:nth-child(6) p:nth-child(1)").click()
        self.driver.find_element(By.CSS_SELECTOR, "label > .appendBottom5").click()
        self.driver.find_element(By.CSS_SELECTOR, ".pushRight > .guestCounter > li:nth-child(3)").click()
        self.driver.find_element(By.CSS_SELECTOR, ".right").click()
        self.driver.find_element(By.CSS_SELECTOR, ".pushRight > .guestCounter > li:nth-child(1)").click()
        self.driver.find_element(By.CSS_SELECTOR, ".appendBottom20 > .gbCounter > li:nth-child(2)").click()
        self.driver.find_element(By.CSS_SELECTOR, ".btnApply").click()
        self.driver.find_element(By.CSS_SELECTOR, ".primaryBtn").click()
        self.driver.execute_script("window.scrollTo(0,189)")
        self.driver.execute_script("window.scrollTo(0,413)")
        self.driver.execute_script("window.scrollTo(0,984)")
        self.driver.execute_script("window.scrollTo(0,1198)")
        self.driver.execute_script("window.scrollTo(0,164)")
        self.driver.find_element(By.CSS_SELECTOR, ".paneView:nth-child(1) #flightCard-1 input").click()
        element = self.driver.find_element(By.CSS_SELECTOR, ".paneView:nth-child(1) #flightCard-1 input")
        actions = ActionChains(self.driver)
        actions.move_to_element(element).perform()
        element = self.driver.find_element(By.CSS_SELECTOR, "body")
        actions = ActionChains(self.driver)
        actions.move_to_element(element, 0, 0).perform()
        self.driver.find_element(By.CSS_SELECTOR, ".paneView:nth-child(2) #flightCard-0 input").click()
        self.driver.find_element(By.ID,
                                 "bookbutton-RKEY:54621f9b-99e7-40fc-a0af-a707b4430f09:559_0~~~RKEY:54621f9b-99e7-40fc-a0af-a707b4430f09:192_0").click()
        self.driver.find_element(By.CSS_SELECTOR, ".multifareCross").click()
        self.driver.close()