from selenium import webdriver
from selenium.webdriver.common.by import By
from Base_Page import BasePage

class HomePage(BasePage):
    Cancel_btn =(By.XPATH,"//span[@class='commonModal__close']")
    Trains_TAB =(By.XPATH,"//span[text()='Trains']")
    FLIGHT_TAB = (By.XPATH, "//span[text()='Flights']")
    click_from =(By.XPATH,"//input[@id='fromCity']")
    FROM_CITY_INPUT = (By.TAG_NAME, "input")
    TO_CITY_INPUT = (By.ID, "toCity")
    SEARCH_BUTTON = (By.XPATH, "//a[text()='Search']")
    def select_train_tab(self):
        self.click_element(*self.Cancel_btn)
        self.click_element(*self.Trains_TAB)
    def select_flight_tab(self):
        self.click_element(*self.FLIGHT_TAB)
    def Click_From(self):
        self.click_element(*self.click_from)
    def enter_from_city(self, city):
        self.enter_text(*self.FROM_CITY_INPUT, city)
    def enter_to_city(self, city):
        self.enter_text(*self.TO_CITY_INPUT, city)
    def click_search(self):
        self.click_element(*self.SEARCH_BUTTON)