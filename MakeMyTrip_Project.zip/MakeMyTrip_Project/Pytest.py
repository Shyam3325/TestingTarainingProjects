import time
import pytest
from selenium import webdriver
from Home_Page import HomePage
from Search_Page import SearchResultsPage
@pytest.fixture(scope="function")
def setup():
    driver = webdriver.Chrome()  # Replace with your driver path
    driver.get("https://www.makemytrip.com")
    driver.maximize_window()
    yield driver
    driver.quit()
def test_search_flights(setup):
    driver = setup
    home_page = HomePage(driver)
    results_page = SearchResultsPage(driver)

    home_page.select_train_tab()
    time.sleep(3)
    home_page.select_flight_tab()
    time.sleep(3)
    home_page.Click_From()
    time.sleep(3)
    home_page.enter_from_city("Bengaluru")
    home_page.enter_to_city("Hyderabad")
    home_page.click_search()
    assert results_page.is_results_displayed(), "Search results not displayed!"