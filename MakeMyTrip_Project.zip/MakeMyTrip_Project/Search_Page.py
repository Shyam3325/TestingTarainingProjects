from selenium.webdriver.common.by import By
from Base_Page import BasePage

class SearchResultsPage(BasePage):
    RESULTS_CONTAINER = (By.ID, "flightResultsContainer")

    def is_results_displayed(self):
        return self.find_element(*self.RESULTS_CONTAINER).is_displayed()