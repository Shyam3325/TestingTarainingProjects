from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://www.login.hiox.com/login?referrer=easycalculation.com")
driver.maximize_window()
time.sleep(6)

text_box = driver.find_element(By.ID,"log_email" )
text_box.send_keys("shyam143pr@gmail.com")
text_box.send_keys(Keys.RETURN)
time.sleep(6)

text_box = driver.find_element(By.NAME, "log_password")
text_box.send_keys("Sam@pr9493!")
text_box.send_keys(Keys.RETURN)
time.sleep(5)