from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://store.webkul.com/customer/account/loginPost/")
driver.maximize_window()
time.sleep(6)

text_box = driver.find_element(By.ID,"wk-login-email" )
text_box.send_keys("shyam143pr@gmail.com")
text_box.send_keys(Keys.RETURN)
time.sleep(6)

text_box = driver.find_element(By.NAME, "login[password]")
text_box.send_keys("Sam@pr9493!")
text_box.send_keys(Keys.RETURN)
time.sleep(5)
