from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://www.easemytrip.com/css/nwhomfiles/desktopmenulogin")
driver.maximize_window()



edit_box = driver.find_element(By.ID,"txtEmail")
edit_box.send_keys("shyam143pr@gmail.com")
edit_box.send_keys(Keys.RETURN)
time.sleep(6)

