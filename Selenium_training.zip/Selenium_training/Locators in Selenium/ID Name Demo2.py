from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://demo.opencart.com/en-gb?route=account/login.login&amp;")
driver.maximize_window()

edit_box = driver.find_element(By.ID,"input-email" )
edit_box.send_keys("shyam143pr@gmail.com")
edit_box.send_keys(Keys.RETURN)
time.sleep(6)

edit_box = driver.find_element(By.NAME, "password")
edit_box.send_keys("Sam@pr9493!")
edit_box.send_keys(Keys.RETURN)
time.sleep(5)

