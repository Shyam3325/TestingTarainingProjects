class BankAccount:
    def __init__(self,account_holder,balance=0):
        self.account_holder = account_holder
        self.balance=balance

    def deposit(self,amount):
        self.balance += amount
        print(f"Deposited RS.{amount}, New Balance :RS{self.balance}")

    def withdraw(self,amount):

        if amount>self.balance:
            print(f"Insufficient funds! Current balance:RS.{self.balance}")
        else:
            self.balance -= amount
            print(f"Withdraw Rs.{amount},New balance: Rs.{self.balance}")

account = BankAccount(account_holder= "M.Shyam Kumar",balance=100000)

account.deposit(50000)
account.withdraw(30000)
account.withdraw(20000)
