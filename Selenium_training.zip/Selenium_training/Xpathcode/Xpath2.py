from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://www.letskodeit.com/login")
driver.maximize_window()
time.sleep(6)

driver.find_element(By.ID,"email" ).send_keys("shyam143pr@gmail.com")
driver.find_element(By.NAME, "password").send_keys("Sam@pr9493!")
driver.find_element(By.XPATH,"/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/form[1]/div[5]/div[1]/button[1]").click()
time.sleep(5)