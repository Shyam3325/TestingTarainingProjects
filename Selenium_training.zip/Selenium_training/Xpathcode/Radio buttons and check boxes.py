from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.letskodeit.com/practice")
time.sleep(3)
bmwRadioBtn=driver.find_element(By.ID,"bmwradio")
bmwRadioBtn.click()
time.sleep(2)

benzRadioBtn=driver.find_element(By.ID,"benzradio")
benzRadioBtn.click()
time.sleep(2)

bmwCheckbox=driver.find_element(By.ID,"bmwcheck")
bmwCheckbox.click()
time.sleep(2)

benzCheckbox=driver.find_element(By.ID,"benzcheck")
benzCheckbox.click()
time.sleep(2)

links =driver.find_elements(By.XPATH,"//div[@class='col-md-12']//a")
print(len(links))

links =driver.find_elements(By.XPATH,"//div[@class='col-md-12']//a")
print(len(links))


print("BMZ Radio button is selected?"+str(bmwRadioBtn.is_selected()))
print("Benz Radio button is selected?"+str(benzRadioBtn.is_selected()))
print("BMZ Checkbox is selected?"+str(bmwCheckbox.is_selected()))
print("Benz Check is selected?"+str(benzCheckbox.is_selected()))







