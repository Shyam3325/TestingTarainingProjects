from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("file:///C:/Users/Gajendra/Documents/IFrame.html")
time.sleep(3)

driver.switch_to.frame("HollandandBarrett")
driver.get("https://auth.hollandandbarrett.com/u/login")
driver.find_element(By.ID,"username").send_keys("shyam143pr@gmail.com")
driver.find_element(By.NAME,"password").send_keys("Sam@pr9493!")
driver.find_element(By.XPATH,"//button[normalize-space()='Sign In']").click()
time.sleep(3)

driver.get("file:///C:/Users/Gajendra/Documents/IFrame.html")
time.sleep(2)
driver.find_element(By.XPATH,"/html/body/a").click()
time.sleep(3)
driver.get("https://www.selenium.dev/")
driver.find_element(By.XPATH,"/html[1]/body[1]/header[1]/nav[1]/div[1]/ul[1]/li[2]/a[1]/span[1]").click()
time.sleep(2)

driver.get("file:///C:/Users/Gajendra/Documents/IFrame.html")
time.sleep(2)
driver.switch_to.frame("Your store")
driver.get("https://demo.opencart.com/")
time.sleep(3)

driver.find_element(By.NAME,"search").send_keys("Product")
time.sleep(3)
driver.find_element(By.XPATH,"//i[@class='fa-solid fa-magnifying-glass']").click()
time.sleep(4)
driver.find_element(By.XPATH,"/html/body").click()












