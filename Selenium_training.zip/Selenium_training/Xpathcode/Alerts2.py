from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.ksrtc.in/login")
time.sleep(3)
driver.find_element(By.XPATH,"//div[@class='btn payee']").click()
time.sleep(2)
driver.find_element(By.XPATH,"//button[@id='okayButton']").click()