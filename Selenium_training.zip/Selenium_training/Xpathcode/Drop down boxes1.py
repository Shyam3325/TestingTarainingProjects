from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("http://www.automationpractice.pl/index.php?id_category=3&controller=category")
time.sleep(2)

dropdown = driver.find_element(By.ID,"selectProductSort")
select = Select(dropdown)
time.sleep(3)

value_options = len(select.options)
print(f"There are {value_options} options in the Sort By Dropdown")

for option in select.options:
    print(option.text)