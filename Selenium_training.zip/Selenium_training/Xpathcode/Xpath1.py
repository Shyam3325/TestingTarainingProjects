from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://auth.hollandandbarrett.com/u/login")
driver.maximize_window()
time.sleep(6)

driver.find_element(By.ID,"username" ).send_keys("shyam143pr@gmail")
driver.find_element(By.NAME, "password").send_keys("Sam@pr9493!")
driver.find_element(By.XPATH,"/html/body/main/section/div/div/div/form/div[2]/button" ).click()
time.sleep(5)
