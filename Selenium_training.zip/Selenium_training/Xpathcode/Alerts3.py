from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.letskodeit.com/practice")
time.sleep(3)
driver.find_element(By.XPATH,"/html[1]/body[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/div[3]/fieldset[1]/input[2]").click()
time.sleep(2)
driver.switch_to.alert.accept()

driver.find_element(By.XPATH,"//input[@id='confirmbtn']").click()
time.sleep(2)
driver.switch_to.alert.accept()

driver.find_element(By.XPATH,"//input[@id='confirmbtn']").click()
time.sleep(2)
driver.switch_to.alert.dismiss()
