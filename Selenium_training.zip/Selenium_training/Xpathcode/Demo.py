from cffi.cffi_opcode import CLASS_NAME
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

#Step:1
#Open the website
baseUrl="https://auth.hollandandbarrett.com/u/login"
driver = webdriver.Chrome()
driver.maximize_window()
driver.get(baseUrl)
time.sleep(5)
driver.save_screenshot(".//baseUrl.png")

#Step:2
#Login with the registered user
edit_box=(driver.find_element(By.ID,"username").send_keys("shyam143pr@gmail.com"))
time.sleep(5)
edit_box=(driver.find_element(By.NAME,"password").send_keys("Sam@pr9493!"))
time.sleep(5)
#terms and conditions
Click_box=(driver.find_element(By.XPATH,"/html/body/main/section/div/div/div/form/div[2]/button").click())
driver.save_screenshot(".//Login successful.png")
time.sleep(5)

#Step:3
#  Add any 2 Vitamin C products from 'Vitamins & Supplements' to the basket

driver.get("https://www.hollandandbarrett.com/")
time.sleep(3)

#selecting Vitamins&Supplements
partial_link ="Vitamins"
link_element =driver.find_element(By.PARTIAL_LINK_TEXT,partial_link)
link_element.click()
time.sleep(2)
#Selecting vitamins
vitamins =driver.find_element(By.XPATH,"//button[normalize-space()='Vitamins']")
vitamins.click()
#Selecting vitamin C products
vitaminc =driver.find_element(By.XPATH,"//div[normalize-space()='Vitamin C']")
vitaminc.click()
time.sleep(2)
#Adding products to basket
Add_Basket=(driver.find_element(By.XPATH,"//body[1]/div[3]/div[10]/div[1]/div[1]/div[1]/div[3]/a[1]/div[1]/div[3]/div[2]/button[1]").click())
Add_Basket=(driver.find_element(By.XPATH,"//a[2]//div[1]//div[3]//div[2]//button[1]").click())

driver.save_screenshot(".//Add_Basket screenshot.png")

#Step:4
# Add any 3 Vegan Chocolate products from 'Vegan' to the basket
vegan=driver.find_element(By.XPATH, "//a[normalize-space()='Home']")
vegan.click()
time.sleep(3)
partial_link ="Vegan"
link_element =driver.find_element(By.PARTIAL_LINK_TEXT,partial_link)
link_element.click()
time.sleep(2)
#Selecting Vegan Chocolates
vegan_choc =driver.find_element(By.XPATH,"//button[normalize-space()='Vegan Chocolate']")
vegan_choc.click()
#Adding Vegan chocolate products to the Basket

driver.find_element(By.XPATH,"//a[1]//div[1]//div[3]//div[2]//button[1]").click()
driver.find_element(By.XPATH,"//a[2]//div[1]//div[3]//div[2]//button[1]").click()
Add_basket=(driver.find_element(By.XPATH,"//a[3]//div[1]//div[3]//div[2]//button[1]").click())
driver.save_screenshot(".//Add_basket screenshot.png")

#Step:5
#Verify all the products are added to the basket
driver.find_element(By.XPATH, "//span[@class='HeaderLinkIcon-module_menuText__umT0M']").click()
time.sleep(3)
basket_items = driver.find_elements(By.CLASS_NAME, "Your basket")
driver.save_screenshot(".//basket_items screenshot.png")

#Step:6
#Verify the subtotal of the products (quantity * price) and total of the basket


P1=driver.find_element(By.XPATH,"//div[normalize-space()='£6.00']").text
Price1=print(float(P1[1:]))
P2=driver.find_element(By.XPATH,"//div[normalize-space()='£0.79']").text
Price2=print(float(P2[1:]))
P3=driver.find_element(By.XPATH,"//div[normalize-space()='£9.48']").text
Price3=print(float(P3[1:]))
P4=driver.find_element(By.XPATH,"//div[normalize-space()='£8.80']").text
Price4=print(float(P4[1:]))
P5=driver.find_element(By.XPATH,"//div[normalize-space()='£5.99']").text
Price5=print(float(P5[1:]))


Total=driver.find_element(By.XPATH,"//div[@class='jsx-1755698353 price-label__price price-label--bold']").text
Sub_total=print(f"Sub_total :{Total[1:]}")

price1 = 6.00
price2 = 0.79
price3 = 9.48
price4 = 8.80
price5 = 5.99

Total_price = float(price1 + price2 + price3 + price4 + price4)
Expected_Subtotal=print(f"Expected_Subtotal:{Total_price:.2f}")


if Expected_Subtotal == Sub_total:
    print("Verified Successfully")
else:
    print("Not Verified")

#Step:7
#Print Page Title
print("Current Page Title:", driver.title)
#Step:8
#Get page Source and Page Source length
page_source = driver.page_source
print("Page Source Length:", len(page_source))

#Step:9
driver.quit()