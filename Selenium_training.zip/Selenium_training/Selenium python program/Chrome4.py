from selenium import webdriver
import time
driver = webdriver.Chrome()
driver.get("https://demo-opencart.com/index.php?route=account/login&language=en-gb")
driver.maximize_window()
time.sleep(5)
driver.minimize_window()
time.sleep(8)
actual_title = driver.title
expected_title = "Account Login"
if actual_title == expected_title:
    print("Title matched")
else:
    print("Title not matched")