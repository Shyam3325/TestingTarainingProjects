from selenium import webdriver
import time

driver = webdriver.Firefox()
driver.get("https://www.bing.com/")
driver.maximize_window()
time.sleep(8)

actual_title = driver.title
expect_title = "Bing"

if actual_title == expect_title:
    print("Title verified")
else:
    print("Title not verified")
