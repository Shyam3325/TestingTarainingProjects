from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.get("https://www.freecrm.com/en")
driver.maximize_window()
time.sleep(8)

actual_title = driver.title
expect_title = "Cogment Free CRM with AI Customer Relationship Management"

if actual_title == expect_title:
    print("Title verified")
else:
    print("Title not verified")