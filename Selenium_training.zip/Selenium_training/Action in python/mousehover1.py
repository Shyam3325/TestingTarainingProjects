from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
import time

#step:1
baseUrl ="https://www.easycalculation.com/index.php#google_vignette"
driver = webdriver.Chrome()
driver.maximize_window()
driver.get(baseUrl)
time.sleep(3)

element =driver.find_element(By.CLASS_NAME,"lang")
itemToClickLocator ="//span[@class='lang']"
time.sleep(2)

try:
    actions = ActionChains(driver)
    actions.move_to_element(element).perform()
    print("Mouse Handovered on 'Squad' element")
    time.sleep(2)
    toplink = driver.find_element(By.XPATH,itemToClickLocator)
    actions.move_to_element(toplink).click().perform()

    print("item clicked")
except:
    print("Mouse Hover failed on element")