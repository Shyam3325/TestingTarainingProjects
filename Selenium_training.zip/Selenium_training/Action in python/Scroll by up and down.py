from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.maximize_window()
driver.get("https://www.letskodeit.com/practice")
time.sleep(3)

#scroll down
driver.execute_script("window.scrollBy(0,1000);")
time.sleep(2)

#scroll up
driver.execute_script("window.scrollBy(0,-1000);")
time.sleep(2)

#scroll Element Into view
element = driver.find_element(By.ID,"mousehover")
driver.execute_script("arguments[0].scrollIntoView(true);",element)
time.sleep(2)
driver.execute_script("window.scrollBy(0,-150);")

time.sleep(2)

